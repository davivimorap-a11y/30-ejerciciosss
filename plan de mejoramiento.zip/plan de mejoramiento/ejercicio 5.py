nota = float(input("Ingrese la calificación de 0.0 a 5.0: "))

if nota >= 3.5 and nota <= 5.0:
    print("Aprobado")
elif nota >= 0.0 and nota < 3.5:
    print("No aprobado")
else:
    print("Calificación inválida")