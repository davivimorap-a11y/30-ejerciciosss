filas = int(input("Ingrese la cantidad de filas: "))

for i in range(1, filas + 1):
    print("*" * i)