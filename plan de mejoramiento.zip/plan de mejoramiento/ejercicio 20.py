clave_fija = 1234
intentos = 0
acceso = False

while intentos < 3:
    clave = int(input("Ingrese la contraseña: "))

    if clave == clave_fija:
        print("Acceso concedido")
        acceso = True
        break
    else:
        intentos += 1
        print("Clave incorrecta")

if acceso == False:
    print("Cuenta bloqueada")