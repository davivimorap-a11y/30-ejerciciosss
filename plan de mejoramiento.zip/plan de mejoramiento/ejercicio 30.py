productos = [
    ("Mouse", 15),
    ("Teclado", 3),
    ("Monitor", 8),
    ("Cable HDMI", 2)
]

for producto in productos:
    nombre = producto[0]
    cantidad = producto[1]

    if cantidad < 5:
        print(nombre, "- Stock crítico")
    else:
        print(nombre, "- Stock suficiente")