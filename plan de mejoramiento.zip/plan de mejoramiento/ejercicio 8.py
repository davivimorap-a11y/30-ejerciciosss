clave = input("Ingrese la contraseña: ")

if clave == "Sena2026":
    print("Acceso concedido")
else:
    print("Acceso denegado")