correos = [
    "usuario@gmail.com",
    "aprendizsena.com",
    "contacto@hotmail.com",
    "correo@dominio"
]

for correo in correos:
    if "@" in correo and "." in correo:
        print(correo, "tiene un formato válido")
    else:
        print(correo, "tiene un formato inválido")