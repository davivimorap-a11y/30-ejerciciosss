for exponente in range(1, 11):
    resultado = 2 ** exponente
    print("2 elevado a", exponente, "=", resultado)