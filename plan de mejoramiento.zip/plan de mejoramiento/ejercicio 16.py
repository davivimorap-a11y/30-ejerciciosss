numero = int(input("Ingrese un número entero positivo: "))
factorial = 1

if numero < 0:
    print("Error: el número debe ser positivo")
else:
    for i in range(1, numero + 1):
        factorial *= i

    print("El factorial es:", factorial)