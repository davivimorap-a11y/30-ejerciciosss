edad = int(input("Ingrese su edad: "))

if edad < 12:
    print("Niño")
elif edad <= 17:
    print("Adolescente")
elif edad <= 59:
    print("Adulto")
else:
    print("Adulto mayor")