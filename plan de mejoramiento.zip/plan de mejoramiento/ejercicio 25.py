nombres = []

while True:
    nombre = input("Ingrese el nombre del aprendiz: ")
    nombres.append(nombre)

    if nombre.lower() == "carlos":
        print("Aprendiz encontrado")
        break

print("Nombres ingresados:", nombres)
print("Operación finalizada.")